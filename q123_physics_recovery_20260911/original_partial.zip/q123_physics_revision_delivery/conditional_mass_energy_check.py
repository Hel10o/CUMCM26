#!/usr/bin/env python3
"""Conditional algebra checks only; NOT a repository-derived drying simulation.

Run: python conditional_mass_energy_check.py --output ./conditional_results.json
All numerical inputs below are unverified against the requested repository.
No event time, PDE conservation, or convergence conclusion is calculated.
"""
from __future__ import annotations
import argparse
import json
import math
import platform
from datetime import datetime, timezone
from pathlib import Path


def calculate() -> dict:
    C0, Ct = 2.55, 0.15
    rho_initial_wet = 820.0
    cp_per_initial_wet_mass = 2600.0
    latent_heat_assumed = 2.4e6
    delta_T_assumed = 40.0
    rho_dry = rho_initial_wet / (1.0 + C0)
    removal_per_dry_mass = C0 - Ct
    removal_per_initial_wet_mass = removal_per_dry_mass / (1.0 + C0)
    water_initial_per_volume = rho_dry * C0
    water_final_per_initial_volume = rho_dry * Ct
    water_removed_per_initial_volume = rho_dry * removal_per_dry_mass
    latent_per_dry = removal_per_dry_mass * latent_heat_assumed
    latent_per_initial_wet = removal_per_initial_wet_mass * latent_heat_assumed
    sensible_per_initial_wet = cp_per_initial_wet_mass * delta_T_assumed
    mass_residual = water_initial_per_volume - water_final_per_initial_volume - water_removed_per_initial_volume
    conversion_residual = rho_dry * (1.0 + C0) - rho_initial_wet
    assert abs(mass_residual) < 1e-10
    assert abs(conversion_residual) < 1e-10
    for value in (rho_dry, latent_per_dry, latent_per_initial_wet):
        assert math.isfinite(value) and value > 0
    return {
        'status': 'PARTIAL_CONDITIONAL_ALGEBRA_ONLY',
        'execution_utc': datetime.now(timezone.utc).isoformat(),
        'python_version': platform.python_version(),
        'source_status': 'C0, rho and cp are conditional examples based on prior user-provided values; repository not verified',
        'assumptions': {
            'C0_kg_water_per_kg_dry': C0,
            'target_C_kg_water_per_kg_dry': Ct,
            'density_interpretation': 'initial wet mass divided by initial total volume',
            'rho_initial_wet_kg_m3': rho_initial_wet,
            'cp_interpretation': 'constant per initial wet mass, illustrative energy comparison only',
            'cp_J_kg_initial_wet_K': cp_per_initial_wet_mass,
            'latent_heat_J_kg_water_ASSUMED_NOT_MEASURED': latent_heat_assumed,
            'temperature_rise_K_ASSUMED_NOT_REPOSITORY_VALUE': delta_T_assumed,
            'volume_basis': 'initial total volume; mass bookkeeping only, no shrinkage dynamics'
        },
        'unrounded_float64_results': {
            'rho_dry_kg_m3': rho_dry,
            'water_removed_kg_per_kg_dry': removal_per_dry_mass,
            'water_removed_kg_per_kg_initial_wet': removal_per_initial_wet_mass,
            'water_initial_kg_m3_initial_volume': water_initial_per_volume,
            'water_final_kg_m3_initial_volume': water_final_per_initial_volume,
            'water_removed_kg_m3_initial_volume': water_removed_per_initial_volume,
            'latent_energy_J_per_kg_dry': latent_per_dry,
            'latent_energy_J_per_kg_initial_wet': latent_per_initial_wet,
            'sensible_energy_J_per_kg_initial_wet': sensible_per_initial_wet,
            'latent_to_sensible_ratio': latent_per_initial_wet / sensible_per_initial_wet,
            'mass_bookkeeping_residual_kg_m3': mass_residual,
            'density_basis_residual_kg_m3': conversion_residual,
            'wrong_density_flux_multiplier': 1.0 + C0
        },
        'checks': {
            'conditional_algebra_checks': 'EXECUTED_AND_PASSED',
            'test_kind': 'synthetic scalar bookkeeping checks, not PDE validation',
            'repository_source_read': 'NOT_VERIFIED',
            'main_commit_sha': None,
            'literature_original_pages_and_equations': 'NOT_VERIFIED',
            'Q1_PDE_run': 'NOT_EXECUTED',
            'Q2_PDE_run': 'NOT_EXECUTED',
            'Q3_PDE_run': 'NOT_EXECUTED',
            'target_reachability': 'NOT_DETERMINED',
            'conservation_of_actual_discretized_model': 'NOT_TESTED',
            'mesh_and_tolerance_convergence': 'NOT_TESTED',
            'old_logs_used_as_new_evidence': False,
            'ready_for_publication': False
        }
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path('conditional_results.json'))
    args = parser.parse_args()
    result = calculate()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # Exclusive creation deliberately refuses to overwrite an existing result.
    with args.output.open('x', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
