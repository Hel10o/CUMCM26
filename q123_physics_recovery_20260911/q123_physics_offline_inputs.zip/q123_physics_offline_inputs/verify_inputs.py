from pathlib import Path
import json, hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/'INPUT_MANIFEST.json').read_text(encoding='utf-8'))
for item in m['files']:
    p=(r/item['path']).resolve()
    if not p.is_relative_to(r): raise ValueError(item['path'])
    b=p.read_bytes()
    if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:
        raise ValueError('Hash mismatch: '+item['path'])
print('PASS',len(m['files']),'files; declared source commit',m['declared_source_commit'])
print('This verifies file integrity, not independent online Git provenance or model correctness.')
