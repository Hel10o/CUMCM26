from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent
m=json.loads((r/'INPUT_MANIFEST.json').read_text(encoding='utf-8'))
seen=set()
for item in m['files']:
    if item['path'] in seen: raise ValueError('Duplicate path')
    seen.add(item['path'])
    p=(r/item['path']).resolve()
    if not p.is_relative_to(r): raise ValueError('Path outside package')
    b=p.read_bytes()
    if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:
        raise ValueError('Hash mismatch: '+item['path'])
print('PASS',len(seen),'files; declared baseline',m['declared_source_commit'])
print('File integrity verified; not independent online provenance or model accuracy.')
